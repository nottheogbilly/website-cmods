local clicks = 0
local firstFrame = true

mod.ui.window("clicker", "Cookie Clicker.", function()
    if firstFrame then
        firstFrame = false
        print("Frames Rendering!")
    end
    ui.text("Clicks: "..clicks)

    if ui.button("Click me!") then
        clicks = clicks + 1
    end
end)
